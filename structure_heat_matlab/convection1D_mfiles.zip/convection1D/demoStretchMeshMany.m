function demoStretchMeshMany(n)
% demoStretchMesh  Plot a stretched mesh
%
% Synopsis:  demoStretchMesh
%            demoStretchMesh(n)
%
% Input:  n = number of control volumes
%
% Output:  One plot with control volumes growing by r = dx(i+1)/dx(i)
%          and second plot with control volumes shrinking by r = dx(i)/dx(i+1)

if nargin<1, n=10;   end
xlen = 1;

rshrink = [0.95  0.9  0.8  0.7  0.6];
rgrow =   [1.05  1.1  1.2  1.3  1.4];


figure('Name','Shrinking sequence');
plotSequenceR(rshrink,xlen,n);


figure('Name','Growing sequence');
plotSequenceR(rgrow,xlen,n);

figure('Name','Vary n at r = 0.9');
plotSequenceN(0.9,xlen,[10 20 30 40]);

figure('Name','Vary n at r = 0.95');
plotSequenceN(0.95,xlen,[10 20 30 40]);

end

% ====================================================
function plotSequenceR(r,xlen,n)
% plotSequenceR  Plot multiple meshes by varying stretching ratio, r

nr = length(r);
for i=1:nr
  subplot(nr,1,i)
  [x,xu] = fvMesh1D(n,xlen,r(i));
  plotMesh(xlen,x,xu);
  set(gca,'Visible','off','Xtick',[],'XtickLabel',[],'Ytick',[],'YtickLabel',[]);
  text(-0.220,0.025,sprintf('r = %-3.2f',r(i)),'FontSize',14);
  text(-0.2,-0.025,sprintf('n = %d',n),'FontSize',14);
end
end
  
% ====================================================
function plotSequenceN(r,xlen,n)
% plotSequenceN  Plot multiple meshes by varying number of CVs, n

nn = length(n);
for i=1:nn
  subplot(nn,1,i)
  [x,xu] = fvMesh1D(n(i),xlen,r);
  plotMesh(xlen,x,xu);
  set(gca,'Visible','off','Xtick',[],'XtickLabel',[],'Ytick',[],'YtickLabel',[]);
  text(-0.220,0.025,sprintf('r = %-3.2f',r),'FontSize',14);
  text(-0.2,-0.025,sprintf('n = %d',n(i)),'FontSize',14);
end
end


% ====================================================
function plotMesh(xlen,x,xu)
% plotMesh  Plot a one-dimensional finite volume mesh

n = length(x)-2;

dy = xlen/12;
for i=2:n+2
  plot([xu(i) xu(i)],[-dy dy],'b-');
  hold('on')
end
plot([min(xu) max(xu)],[dy dy],'b-',[min(xu) max(xu)],[-dy -dy],'b-');
z = zeros(n,1);
plot(x(2:n+1),z,'o',xu(2),0,'rs',xu(n+2),0,'rs');
hold('off')
axis('equal');

end