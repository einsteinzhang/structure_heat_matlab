function refineConvect1D(mm,u,gam)
% refineConvect1D  Mesh refinement of solutions to 1D advection-diffusion equation.
%                  Obtain CDS and UDS solutions at different mesh sizes.
%
% Synopsis: refineConvect1D
%           refineConvect1D(mm)
%           refineConvect1D(mm,u)
%           refineConvect1D(mm,u,gam)
%
% Input:  mm = vector of m values.  m is the number of nodes (including boundary
%              nodes) in the domain.  Default: mm = [8 16 32 64 128 256 512].
%              CDS and UDS solutions are obtained for each m in mm.
%         u   = (optional, scalar) uniform velocity.  Default:  u = 5
%         gam = (optional, scalar) diffusion coefficient;  Default:  gam = 0.1
%
% Output:  Table of truncation errors versus mesh size.  Plot of same data.

if nargin<1, mm = [8 16 32 64 128 256 512 1024 2048];  end    %  Sequence of meshes
if nargin<2, u = 5;           end
if nargin<3, gam = 0.1;       end

% --- Constants
xlen = 1;           %  Length of the domain
phib = [1 0];       %  boundary values
PeL = u*xlen/gam;
erru = zeros(size(mm));  errc = erru;    %  Preallocate for efficiency

% --- Loop over mesh sizes
for i = 1:length(mm)
  [x,xw,dx,delxw] = fvMesh1D(mm(i)-2,xlen);            %  Uniform mesh
  [aw,ap,ae,b] = upwind1D(u,gam,x,xw,dx,delxw,phib);   %  Get UDS coefficients
  phiu = tridiagSolve(ap,-ae,-aw,b);                   %     and solve
  [aw,ap,ae,b] = central1D(u,gam,x,xw,dx,delxw,phib);  %  Get CDS coefficients
  phic = tridiagSolve(ap,-ae,-aw,b);                   %     and solve
  pe = phib(1) + (phib(2)-phib(1))*(exp(u*x/gam)-1)/(exp(PeL)-1);  %  Exact solution
  erru(i) = norm(phiu-pe,inf);   errc(i) = norm(phic-pe,inf);      %  Maximum errors
end

% --- Plot error versus mesh dimension, and print same data in a table
Deltax = xlen./(mm-2);              %  CV sizes
loglog(Deltax,errc,'o--',Deltax,erru,'*--');
xlabel('\Delta x');   ylabel('Max error');
legend('Central','Upwind','Location','northwest');

fprintf('\n\nSolution for Pe_L = %f\n',PeL)
fprintf('\n                                -- Upwind --     -- Cent. Diff. --\n');
fprintf('                                Max      Error     Max      Error\n');
fprintf('    m      Delta x     Pe_x    error     ratio    error     ratio\n');
for i=1:length(errc)
  fprintf('%5d    %9.6f   %6.2f  %8.5f',mm(i),Deltax(i),Deltax(i)*u/gam,erru(i));
  if i>1
    fprintf(' %7.2f   %8.5f %7.2f\n',erru(i-1)/erru(i),errc(i),errc(i-1)/errc(i));
  else
    fprintf('           %8.5f\n',errc(i));
  end
end