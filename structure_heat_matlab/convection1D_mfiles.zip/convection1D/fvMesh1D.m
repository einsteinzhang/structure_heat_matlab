function [x,xw,dx,delxw] = fvMesh1D(nx,xlen,r)
% fvMesh1D  Create one-dimensional finite-volume mesh.  Uniform meshes and
%           stretched non-uniform meshes are supported.
%
% Synopsis:  [x,xw] = fvMesh1D
%            [x,xw] = fvMesh1D(nx)
%            [x,xw] = fvMesh1D(nx,xlen)
%            [x,xw] = fvMesh1D(nx,xlen,r)
%            [x,xw,dx] = fvMesh1D(...)
%            [x,xw,dx,delxw] = fvMesh1D(...)
%
% Input: nx   = Number of cells (internal CVs, not nodes). Default: nx=10
%        xlen = overall length of the mesh.  Default:  xlen = 1
%        r = growth ratio:  dx(i+1) = r*dx(i).  Default:  r = 1, i.e mesh
%            is uniform.  If r>1 control volume widths increase with x.
%            If r<1, control volume widths decrease with x.
%
% Output:  x = vector of node locations, including nodes on the boundaries
%          xw = vector of interface locations on east of each node
%               xw(1) = xw(2) = 0,  xw(nx+2) = xlen
%          dx = vector of CV widths:  dx(i) = xw(i+1)-xw(i)
%          delxw = vector of x(i) - x(i-1);   dx(1)=0

if nargin<1,  nx = 10;   end
if nargin<2,  xlen = 1;  end
if nargin<3,  r = 1;     end

% --- Create a mesh where dx(i+1) = r*dx(i)
if abs(r-1)<10*eps;
  s = nx;               %  Mesh is uniform, limit as s->1 is n;  avoid 1/0
else
  s = (1-r^nx)/(1-r);   %  Normal formula for stretched mesh
end
dx = xlen/s;            %  Width of smallest control volume
xw = zeros(nx+2,1);
for i=3:nx+2
  xw(i) = xw(i-1) + dx;
  dx = dx*r;
end

% --- Now that control volumes are defined, locate nodes in the centroids
x = zeros(size(xw));
for i=2:nx+1
  x(i) = (xw(i)+xw(i+1))/2;
end
x(nx+2) = xlen;

% --- Compute vectors of control volume widths
if nargout>2,  dx = [ diff(xw); 0];    end   %  CV widths:    dx(i) = xw(i+1) - xw(i)
if nargout>3,  delxw = [0; diff(x)];   end   %  node spacing: delxw(i) = x(i) - x(i-1)