function demoConvect1D(scheme,m,u,gam,r)
% demoConvect1D  Test finite volume solution to 1D advection-diffusion equation
%
% Synopsis:  demoConvect1D
%            demoConvect1D(scheme)
%            demoConvect1D(scheme,m)
%            demoConvect1D(scheme,m,u,)
%            demoConvect1D(scheme,m,u,gam)
%            demoConvect1D(scheme,m,u,gam,r)
%
% Input:  scheme = (optional,string) indicates convection modeling scheme
%                  scheme = 'UDS' for upwind differencing
%                           'CDS' for central differencing
%         m   = (optional) total number of nodes;  Default:  m = 12
%                Internal cell width = 1/(m-2).  Domain length is 1
%         u   = (optional, scalar) uniform velocity.  Default:  u = 5
%         gam = (optional, scalar) diffusion coefficient;  Default:  gam = 0.1
%         r   = mesh stretching ratio.  If r=1, mesh is uniform
%               If r>1 control volume widths increase with x.  If r<1, control
%               volume widths decrease with x.
%
% Output:  Plot exact and numerical solutions, print max error in numerical solution

if nargin<1, scheme='CDS';  end
if nargin<2, m = 12;        end
if nargin<3, u = 5;         end
if nargin<4, gam = 0.1;     end
if nargin<5, r = 1;         end

% --- Set constants and default input values
xlen = 1;        %  domain length
phib = [1 0];    %  boundary values

% --- Create the mesh.  fvMesh1D works for uniform or stretched meshes
[x,xw,dx,delxw] = fvMesh1D(m-2,xlen,r);

% --- Get CVFD coefficients and solve the system
if strcmpi(scheme,'UDS')
  [aw,ap,ae,b] = upwind1D(u,gam,x,xw,dx,delxw,phib);
elseif strcmpi(scheme,'CDS')
  [aw,ap,ae,b] = central1D(u,gam,x,xw,dx,delxw,phib);
else
  error('scheme = %s is not supported',scheme);
end
phi = tridiagSolve(ap,-ae,-aw,b);     %  solve the system of equations

% --- Evaluate exact solution and maximum error in the numerical solution
PeL = u*xlen/gam;
pe = phib(1) + (phib(2)-phib(1))*(exp(u*x/gam) - 1)/(exp(PeL)-1);
maxerr = norm(phi-pe,inf);
Pex = u*dx(2:end-1)/gam;   Pexave = u*xlen/(m-2)/gam;
fprintf('PeL = %5.3f  Pex_ave, max(Pex), min(Pex) = %5.3f,  %5.3f,  %5.3f\n',...
         PeL,Pexave,max(Pex),min(Pex));
fprintf('\tMax error = %6.4f for %s scheme\n',maxerr,scheme);

% --- plot results
xe = linspace(0,xlen);    %  many x values makes smooth curve for exact solution
pe = phib(1) + (phib(2)-phib(1))*(exp(u*xe/gam) - 1)/(exp(u*xlen/gam)-1);
plot(x,phi,'o--',xe,pe,'-');
legend(sprintf('%s solution',scheme),'exact','Location','northwest');
xlabel('x');   ylabel('\phi','Rotation',0);  axis([0 xlen  min(phib)  1.5*max(phib)])
text(0.1,0.4,sprintf('PeL = %-4.1f,  Pex_{ave} = %-4.1f',PeL,Pexave),'Fontsize',14);
text(0.1,0.25,sprintf('%s scheme,  Max error = %-5.3f',scheme,maxerr),'Fontsize',14);