function compConvect1D(m,u,gam,r)
% compConvect1D  Compare CDS and UDS schemes for 1D advection-diffusion equation.
%                Plot a comparision with exact solution, and print truncation errors.
%
% Synopsis:  compConvect1D
%            compConvect1D(m)
%            compConvect1D(m,u)
%            compConvect1D(m,u,gam)
%            compConvect1D(m,u,gam,r)
%
% Input: m   = total number of nodes;   Number of interior cells is m-2
%        u   = (scalar) uniform velocity.
%        gam = (scalar) uniform diffusion coefficient
%        r   = mesh stretching ratio.  If r=1, mesh is uniform
%
% Output:  Plot of central difference and upwind difference solutions.  Print
%          out of truncation errors

if nargin<1, m = 12;      end    %  mesh size
if nargin<2, u = 5;       end
if nargin<3, gam = 0.1;   end
if nargin<4, r = 1;       end

% --- Constants
xlen = 1;           %  Length of the domain
phib = [1 0];       %  boundary values

% --- Get CVFD coefficients and solve the system
[x,xw,dx,delxw] = fvMesh1D(m-2,xlen,r);              %  Create the mesh
[aw,ap,ae,b] = central1D(u,gam,x,xw,dx,delxw,phib);  %  Central difference scheme
phic = tridiagSolve(ap,-ae,-aw,b);                   %  solve the system of equations
[aw,ap,ae,b] = upwind1D(u,gam,x,xw,dx,delxw,phib);   %  Upwind difference scheme
phiu = tridiagSolve(ap,-ae,-aw,b);                   %  solve the system of equations

% --- Compare with exact solution
PeL = u*xlen/gam;
pe = phib(1) + (phib(2)-phib(1))*(exp(u*x/gam) - 1)/(exp(PeL)-1);  %  Exact solution
errc = norm(phic-pe,inf);  erru = norm(phiu-pe,inf);               %  Maximum errors
Pex = u*dx(2:end-1)/gam;    %  Local Pe where dx>0
Pexave = u*xlen/(m-2)/gam;  %  Pe based on "average" dx
fprintf('PeL = %5.3f  Pex_ave, max(Pex), min(Pex) = %5.3f,  %5.3f,  %5.3f\n',...
         PeL,Pexave,max(Pex),min(Pex));
fprintf('\tMax error = %11.3e for CDS scheme\n',errc);
fprintf('\tMax error = %11.3e for UDS scheme\n',erru);

% --- Plot results
xe = linspace(0,xlen);  %  For smooth curve use 100 points independent of mesh size
pe = phib(1) + (phib(2)-phib(1))*(exp(u*xe/gam) - 1)/(exp(PeL)-1);
plot(x,phic,'o--',x,phiu,'*--',xe,pe,'k-');
xlabel('x');   ylabel('\phi','Rotation',0);
legend('Central','Upwind','Exact','Location','Northwest');
text(0.1,0.5,sprintf('Pe_L = %-3.1f,   Pe_x = %-3.1f',PeL,Pexave),'Fontsize',14);
text(0.1,0.1,sprintf('||e_c|| = %5.3f,    ||e_u|| = %5.3f',errc,erru),'Fontsize',14);
axis([0 xlen -0.5 2]);