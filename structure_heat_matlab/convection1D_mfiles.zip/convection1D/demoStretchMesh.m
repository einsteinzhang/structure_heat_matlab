function demoStretchMesh(r,n)
% demoStretchMesh  Plot a stretched mesh
%
% Synopsis:  demoStretchMesh
%            demoStretchMesh(r)
%            demoStretchMesh(r,n)
%
% Input:  r = stretch ratio
%         n = number of control volumes
%
% Output:  One plot with control volumes growing by r = dx(i+1)/dx(i)
%          and second plot with control volumes shrinking by r = dx(i)/dx(i+1)

if nargin<1, r=1.1;  end
if nargin<2, n=10;   end
xlen = 1;

% --- Mesh that grows with x 
subplot(2,1,1)
[x,xu] = fvMesh1D(n,xlen,r);
plotMesh(xlen,x,xu);
set(gca,'Ytick',[],'YtickLabel',[]);    %  y ticks and labels are meaningless
title(sprintf('r = %-6.3f    n = %d',r,n));

% --- Mesh that shrinks with x
subplot(2,1,2)
[x,xu] = fvMesh1D(n,xlen,1/r);
plotMesh(xlen,x,xu);
set(gca,'Ytick',[],'YtickLabel',[]);    %  y ticks and labels are meaningless

% ====================================================
function plotMesh(xlen,x,xu)
% plotMesh  Plot a one-dimensional finite volume mesh

n = length(x)-2;

dy = xlen/n/2;
for i=2:n+2
  plot([xu(i) xu(i)],[-dy dy],'b-');
  hold('on')
end
plot([min(xu) max(xu)],[dy dy],'b-',[min(xu) max(xu)],[-dy -dy],'b-');
z = zeros(n,1);
plot(x(2:n+1),z,'o',xu(2),0,'rs',xu(n+2),0,'rs');
hold('off')
axis('equal');
