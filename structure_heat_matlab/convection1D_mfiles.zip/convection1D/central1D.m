function [aw,ap,ae,b] = central1D(u,gam,x,xw,dx,delxw,phib,src)
% central1D  Central difference coefficients for 1D advection-diffusion equation
%
% Synopsis:  [aw,ap,ae,b] = central1D(u,gam,x,xw,phib)
%            [aw,ap,ae,b] = central1D(u,gam,x,xw,phib,src)
%
% Input: u   = (scalar) uniform velocity.
%        gam = (scalar) uniform diffusion coefficient
%        x   =  vector of positions of cell centers.  There are m-2 interior cells.
%        xw  =  vector of positions of west faces of cells.
%        phib = two-element vector containing boundary values. phib(1) = phi at x=0;
%               phib(2) = phi at x=xlen
%        src = (optional) source term.  If no value is given, src=0 is assumed.  If
%              src is a scalar (constant), it is replicated as a uniform source term.
%              Otherwise, src can be a row or column vector with m elements.  The i=1
%              and i=m elements are ignored, as these correspond to boundary nodes.
%
% Output: aw,ap,ae = coefficients of 3 point central difference scheme
%         b = right hand side vector
%         x = vector of locations of cell centers

if nargin<8, src = 0;  end   %  Default: no source term

% --- Compute CVFD coefficients
m = length(x);
ae = zeros(m,1);  aw = ae;
for i=2:m-1
  be = 0.5*dx(i)/delxw(i+1);
  ae(i) = (gam/delxw(i+1) - u*be)/dx(i);
  bw = 0.5*dx(i)/delxw(i);
  aw(i) = (gam/delxw(i)   + u*bw)/dx(i);
end
ap = ae + aw;    %  ap is a vector with same shape as ae and aw

% --- Create right hand side vector
if numel(src) == 1      %  src is a scalar ==> replicate for all cells
  b = src*ones(m,1);
elseif numel(src) == m  %  src is properly sized
  b = src(:);           %  make sure it's a column vector
else
  error('size(src) = %d %d is incompatible with mesh definition',m);
end

% --- Apply boundary conditions
ap(1) = 1;   ae(1) = 0;   b(1) = phib(1);    %  prescribed phi at west boundary
aw(m) = 0;   ap(m) = 1;   b(m) = phib(2);    %  prescribed phi at east boundary